/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./styles/News.module.css":
/*!********************************!*\
  !*** ./styles/News.module.css ***!
  \********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"container\": \"News_container__O_QEQ\",\n\t\"card\": \"News_card__t8U0C\",\n\t\"date\": \"News_date__443Ji\",\n\t\"title\": \"News_title__SthQb\",\n\t\"url\": \"News_url__WEqw8\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvTmV3cy5tb2R1bGUuY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXdzLXRhc2svLi9zdHlsZXMvTmV3cy5tb2R1bGUuY3NzP2Y0ZmMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwiY29udGFpbmVyXCI6IFwiTmV3c19jb250YWluZXJfX09fUUVRXCIsXG5cdFwiY2FyZFwiOiBcIk5ld3NfY2FyZF9fdDhVMENcIixcblx0XCJkYXRlXCI6IFwiTmV3c19kYXRlX180NDNKaVwiLFxuXHRcInRpdGxlXCI6IFwiTmV3c190aXRsZV9fU3RoUWJcIixcblx0XCJ1cmxcIjogXCJOZXdzX3VybF9fV0VxdzhcIlxufTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./styles/News.module.css\n");

/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _news__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./news */ \"./pages/news/index.tsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_news__WEBPACK_IMPORTED_MODULE_1__]);\n_news__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\nconst Home = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_news__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Chetan\\\\Documents\\\\news-task\\\\pages\\\\index.tsx\",\n            lineNumber: 10,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Chetan\\\\Documents\\\\news-task\\\\pages\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBSXlCO0FBRXpCLE1BQU1DLElBQUksR0FBYSxJQUFNO0lBQzNCLHFCQUNFLDhEQUFDQyxLQUFHO2tCQUNGLDRFQUFDRiw2Q0FBSTs7OztxQkFBRzs7Ozs7aUJBQ0osQ0FDUDtBQUNILENBQUM7QUFFRCxpRUFBZUMsSUFBSSIsInNvdXJjZXMiOlsid2VicGFjazovL25ld3MtdGFzay8uL3BhZ2VzL2luZGV4LnRzeD8wN2ZmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmV4dFBhZ2UgfSBmcm9tICduZXh0J1xuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXG5pbXBvcnQgTmV3cyBmcm9tICcuL25ld3MnXG5cbmNvbnN0IEhvbWU6IE5leHRQYWdlID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8TmV3cyAvPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEhvbWVcbiJdLCJuYW1lcyI6WyJOZXdzIiwiSG9tZSIsImRpdiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/index.tsx\n");

/***/ }),

/***/ "./pages/news/index.tsx":
/*!******************************!*\
  !*** ./pages/news/index.tsx ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"getServerSideProps\": () => (/* binding */ getServerSideProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_News_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../styles/News.module.css */ \"./styles/News.module.css\");\n/* harmony import */ var _styles_News_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_News_module_css__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! swr */ \"swr\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_4__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_1__]);\nswr__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n\nconst prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_4__.PrismaClient();\nasync function getServerSideProps() {\n    const newsData = await prisma.News.findMany();\n    return {\n        props: {\n            data: newsData\n        }\n    };\n}\nconst News = ()=>{\n    const fetcher = (url)=>{\n        const options = {\n            method: \"GET\",\n            url: url,\n            params: {\n                companyname: \"Apple Inc.\"\n            },\n            headers: {\n                \"X-RapidAPI-Key\": \"8f217731c5msh8f9b26a3225e183p181599jsn3505f7fa5b8a\",\n                \"X-RapidAPI-Host\": \"gaialens-esg-news.p.rapidapi.com\"\n            }\n        };\n        return axios__WEBPACK_IMPORTED_MODULE_2___default().request(options).then(function(response) {\n            console.error(\"RES ==>>\", response);\n            return response.data;\n        }).catch(function(error) {\n            console.error(\"err ==>>\", error);\n        });\n    };\n    const { data , error  } = (0,swr__WEBPACK_IMPORTED_MODULE_1__[\"default\"])(\"https://gaialens-esg-news.p.rapidapi.com/news\", fetcher);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_5___default().container),\n        children: data === null || data === void 0 ? void 0 : data.map((news)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_3__.Card, {\n                    className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_5___default().card),\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_5___default().date),\n                            children: [\n                                \"NEWS | \",\n                                news.date\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\Chetan\\\\Documents\\\\news-task\\\\pages\\\\news\\\\index.tsx\",\n                            lineNumber: 48,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),\n                            children: news.title\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Chetan\\\\Documents\\\\news-task\\\\pages\\\\news\\\\index.tsx\",\n                            lineNumber: 49,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_5___default().url),\n                            children: news.url\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Chetan\\\\Documents\\\\news-task\\\\pages\\\\news\\\\index.tsx\",\n                            lineNumber: 50,\n                            columnNumber: 11\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\Chetan\\\\Documents\\\\news-task\\\\pages\\\\news\\\\index.tsx\",\n                    lineNumber: 47,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false))\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Chetan\\\\Documents\\\\news-task\\\\pages\\\\news\\\\index.tsx\",\n        lineNumber: 44,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (News);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9uZXdzL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDaUQ7QUFDeEI7QUFDQTtBQUNFO0FBQ21CO0FBRTlDLE1BQU1LLE1BQU0sR0FBRyxJQUFJRCx3REFBWSxFQUFFO0FBRTFCLGVBQWVFLGtCQUFrQixHQUFHO0lBQ3pDLE1BQU1DLFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLElBQUksQ0FBQ0MsUUFBUSxFQUFFO0lBRTdDLE9BQU87UUFDTEMsS0FBSyxFQUFFO1lBQ0xDLElBQUksRUFBRUosUUFBUTtTQUNmO0tBQ0Y7QUFDSCxDQUFDO0FBRUQsTUFBTUMsSUFBSSxHQUFHLElBQU07SUFFakIsTUFBTUksT0FBTyxHQUFHLENBQUNDLEdBQVcsR0FBSztRQUMvQixNQUFNQyxPQUFPLEdBQUc7WUFDZEMsTUFBTSxFQUFFLEtBQUs7WUFDYkYsR0FBRyxFQUFFQSxHQUFHO1lBQ1JHLE1BQU0sRUFBRTtnQkFBQ0MsV0FBVyxFQUFFLFlBQVk7YUFBQztZQUNuQ0MsT0FBTyxFQUFFO2dCQUNQLGdCQUFnQixFQUFFLG9EQUFvRDtnQkFDdEUsaUJBQWlCLEVBQUUsa0NBQWtDO2FBQ3REO1NBQ0Y7UUFFRCxPQUFPaEIsb0RBQWEsQ0FBQ1ksT0FBTyxDQUFDLENBQUNNLElBQUksQ0FBQyxTQUFVQyxRQUFRLEVBQUU7WUFDckRDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLFVBQVUsRUFBQ0YsUUFBUSxDQUFDLENBQUM7WUFDbkMsT0FBT0EsUUFBUSxDQUFDVixJQUFJLENBQUM7UUFDdkIsQ0FBQyxDQUFDLENBQUNhLEtBQUssQ0FBQyxTQUFVRCxLQUFLLEVBQUU7WUFDeEJELE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLFVBQVUsRUFBQ0EsS0FBSyxDQUFDLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsTUFBTSxFQUFFWixJQUFJLEdBQUVZLEtBQUssR0FBRSxHQUFHdEIsK0NBQU0sQ0FBQywrQ0FBK0MsRUFBRVcsT0FBTyxDQUFDO0lBRXhGLHFCQUNFLDhEQUFDYSxLQUFHO1FBQUNDLFNBQVMsRUFBRTFCLDBFQUFnQjtrQkFDN0JXLElBQUksYUFBSkEsSUFBSSxXQUFLLEdBQVRBLEtBQUFBLENBQVMsR0FBVEEsSUFBSSxDQUFFaUIsR0FBRyxDQUFDLENBQUNDLElBQVMsaUJBQ3JCOzBCQUNFLDRFQUFDMUIsc0NBQUk7b0JBQUN1QixTQUFTLEVBQUUxQixxRUFBVzs7c0NBQzFCLDhEQUFDeUIsS0FBRzs0QkFBQ0MsU0FBUyxFQUFFMUIscUVBQVc7O2dDQUFFLFNBQU87Z0NBQUM2QixJQUFJLENBQUNFLElBQUk7Ozs7OztxQ0FBTztzQ0FDckQsOERBQUNOLEtBQUc7NEJBQUNDLFNBQVMsRUFBRTFCLHNFQUFZO3NDQUFHNkIsSUFBSSxDQUFDRyxLQUFLOzs7OztxQ0FBTztzQ0FDaEQsOERBQUNQLEtBQUc7NEJBQUNDLFNBQVMsRUFBRTFCLG9FQUFVO3NDQUFHNkIsSUFBSSxDQUFDaEIsR0FBRzs7Ozs7cUNBQU87Ozs7Ozs2QkFDdkM7NkJBQ04sQ0FDRjs7Ozs7aUJBQ0csQ0FDUDtBQUNILENBQUM7QUFFRCxpRUFBZUwsSUFBSSIsInNvdXJjZXMiOlsid2VicGFjazovL25ld3MtdGFzay8uL3BhZ2VzL25ld3MvaW5kZXgudHN4P2RjNWYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBOZXh0UGFnZSB9IGZyb20gJ25leHQnXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vLi4vc3R5bGVzL05ld3MubW9kdWxlLmNzcydcclxuaW1wb3J0IHVzZVNXUiBmcm9tICdzd3InO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXHJcbmltcG9ydCB7IENhcmQgfSBmcm9tICdhbnRkJ1xyXG5pbXBvcnQgeyBQcmlzbWFDbGllbnQgfSBmcm9tICdAcHJpc21hL2NsaWVudCc7XHJcblxyXG5jb25zdCBwcmlzbWEgPSBuZXcgUHJpc21hQ2xpZW50KCk7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCkge1xyXG4gIGNvbnN0IG5ld3NEYXRhID0gYXdhaXQgcHJpc21hLk5ld3MuZmluZE1hbnkoKVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHtcclxuICAgICAgZGF0YTogbmV3c0RhdGFcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmNvbnN0IE5ld3MgPSAoKSA9PiB7XHJcbiAgXHJcbiAgY29uc3QgZmV0Y2hlciA9ICh1cmw6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgbWV0aG9kOiAnR0VUJyxcclxuICAgICAgdXJsOiB1cmwsXHJcbiAgICAgIHBhcmFtczoge2NvbXBhbnluYW1lOiAnQXBwbGUgSW5jLid9LFxyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgJ1gtUmFwaWRBUEktS2V5JzogJzhmMjE3NzMxYzVtc2g4ZjliMjZhMzIyNWUxODNwMTgxNTk5anNuMzUwNWY3ZmE1YjhhJyxcclxuICAgICAgICAnWC1SYXBpZEFQSS1Ib3N0JzogJ2dhaWFsZW5zLWVzZy1uZXdzLnAucmFwaWRhcGkuY29tJ1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICByZXR1cm4gYXhpb3MucmVxdWVzdChvcHRpb25zKS50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiUkVTID09Pj5cIixyZXNwb25zZSk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgfSkuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJlcnIgPT0+PlwiLGVycm9yKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gdXNlU1dSKCdodHRwczovL2dhaWFsZW5zLWVzZy1uZXdzLnAucmFwaWRhcGkuY29tL25ld3MnLCBmZXRjaGVyKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxyXG4gICAgICB7ZGF0YT8ubWFwKChuZXdzOiBhbnkpID0+IFxyXG4gICAgICA8PlxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT17c3R5bGVzLmNhcmR9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5kYXRlfT5ORVdTIHwge25ld3MuZGF0ZX08L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudGl0bGV9PntuZXdzLnRpdGxlfTwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy51cmx9PntuZXdzLnVybH08L2Rpdj5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOZXdzXHJcbiJdLCJuYW1lcyI6WyJzdHlsZXMiLCJ1c2VTV1IiLCJheGlvcyIsIkNhcmQiLCJQcmlzbWFDbGllbnQiLCJwcmlzbWEiLCJnZXRTZXJ2ZXJTaWRlUHJvcHMiLCJuZXdzRGF0YSIsIk5ld3MiLCJmaW5kTWFueSIsInByb3BzIiwiZGF0YSIsImZldGNoZXIiLCJ1cmwiLCJvcHRpb25zIiwibWV0aG9kIiwicGFyYW1zIiwiY29tcGFueW5hbWUiLCJoZWFkZXJzIiwicmVxdWVzdCIsInRoZW4iLCJyZXNwb25zZSIsImNvbnNvbGUiLCJlcnJvciIsImNhdGNoIiwiZGl2IiwiY2xhc3NOYW1lIiwiY29udGFpbmVyIiwibWFwIiwibmV3cyIsImNhcmQiLCJkYXRlIiwidGl0bGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/news/index.tsx\n");

/***/ }),

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "swr":
/*!**********************!*\
  !*** external "swr" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();